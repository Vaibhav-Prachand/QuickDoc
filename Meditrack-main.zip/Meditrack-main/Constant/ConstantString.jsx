export default{
    NoMedication:'No Medications!',
    MedicationSubText:'You have 0 medication setup, Kindly setup a new one',
    AddNewMedicationButton:'+ Add New Medication'
}